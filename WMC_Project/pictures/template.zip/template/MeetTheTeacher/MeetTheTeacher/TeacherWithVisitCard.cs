﻿using System.Net;

namespace MeetTheTeacher
{
    /// <summary>
    /// Klasse, die einen Detaileintrag mit Link auf dem Namen realisiert.
    /// </summary>
    public class TeacherWithVisitCard
    {
        private const string BaseUrl = "https://www.htl-leonding.at/kontakt/lehrer-innen/";
    }

}
