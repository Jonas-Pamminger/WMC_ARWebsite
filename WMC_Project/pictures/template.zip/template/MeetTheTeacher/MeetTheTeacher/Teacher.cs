﻿using System;
using System.Net;
using System.Text;

namespace MeetTheTeacher
{
    /// <summary>
    /// Verwaltet einen Eintrag in der Sprechstundentabelle
    /// </summary>
    public class Teacher
    { 
 
    }
}
