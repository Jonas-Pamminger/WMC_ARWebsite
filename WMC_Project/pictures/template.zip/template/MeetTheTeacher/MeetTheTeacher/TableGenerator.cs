﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Net;
using System.Web;
using System.Linq;

namespace MeetTheTeacher
{
    public enum SortOrder
    {
        SortByName,
        SortByHour
    }
    /// <summary>
    /// Verwaltung der Gesamtliste inklusive Controller
    /// </summary>
    public class TableGenerator
    {
        const string TeachersFileName = "2122-teachers.csv";
        const string DetailsFileName = "2122-teacher-with-details.csv";

        private Dictionary<string, Teacher> _allTeachers = new Dictionary<string, Teacher>();
        private SortOrder _sortOrder;

        public TableGenerator(SortOrder sortOrder)
        {
            _sortOrder = sortOrder;
        }

        public int ReadTeachersFromCsv()
        {
            // TODO 1: Read data from teacher-with-details.csv and create TeachersWithVisitCards

            // TODO 2: Read data from teachers.csv and create Teachersm or merge with TeachersWithVisitCards
            return _allTeachers.Count;
        }

        public string GenerateHtmlTable()
        {         
            string header =
@"<table id=""tabelle"">

<tr>
<th align=""center"">Name</th>
<th align=""center"">Tag</th>
<th align=""center"">Einheit</th>
<th align=""center"">Zeit</th>
<th align=""center"">Raum</th>
</tr>

";
            StringBuilder sb = new StringBuilder(header);

            // TODO 3: Sort teachers and add a table row for each teacher to the string builder

            return sb.ToString();
        }


    }
}
