﻿using System;
using System.IO;

namespace MeetTheTeacher
{
    internal class Program
    {
        const string HtmlOutputFileName = "Output.html";
        static void Main(string[] args)
        {
            Console.WriteLine("Welcome @ HTL Leo HTML table generator");
            Console.WriteLine("======================================");
            SortOrder sortOrder = SelectSortOrder(args);

            TableGenerator generator = new TableGenerator(sortOrder);

            int count = generator.ReadTeachersFromCsv();
            Console.WriteLine($"In total {count} teachers created from csv files.");

            string html = generator.GenerateHtmlTable();

            File.WriteAllText(HtmlOutputFileName, html);
            Console.WriteLine($"File {HtmlOutputFileName} has been generated.");
        }

        private static SortOrder SelectSortOrder(string[] args)
        {
            // TODO 4: Read command line argument and try to parse into SortOrder

            return SortOrder.SortByName;
        }
    }
}
